export class Employee {
    public id!: number;
    public name!: string;
    public gender!: boolean;
    public role!: string;
 }
 